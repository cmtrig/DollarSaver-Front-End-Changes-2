
namespace DollarSaver.Web.controls {


    /// <summary>
    /// NavMenu class.
    /// </summary>
    /// <remarks>
    /// Auto-generated class.
    /// </remarks>
    public partial class Name {
        protected global::System.Web.UI.WebControls.Label nameLabel;
    }
}